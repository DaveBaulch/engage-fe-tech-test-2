<template>
  <div>
    <router-link to="test">Test assets</router-link>
  </div>
</template>

<script>
export default {
  name: "Index",
  components: {},
  metaInfo() {
    return {
      title: "Homepage • Swiftly",
    };
  },
  methods: {},
};
</script>
